# OfflineBeats — Android Studio project

A Spotify-inspired offline music player starter app for Android. It scans audio files already stored on the device, lets the user search the library, and plays tracks locally without streaming or an account.

## Included
- Dark Spotify-inspired interface with green accent
- Local device audio library via Android MediaStore
- Audio permission request for Android 13+ and older Android versions
- Search by song title or artist
- Play, pause, previous, next, shuffle and repeat-one
- Basic playback progress display

## Build an installable APK
1. Install Android Studio (current stable version).
2. Open this folder in Android Studio.
3. Allow Gradle sync to complete (internet is needed once to download Android Gradle Plugin).
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio creates the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to your Android phone and install it. If Android asks, allow installation from the file manager you used.

## Notes
- This is a native Android project, not a finished APK. This environment did not have the Android SDK or Gradle installed, so the APK could not be compiled or tested here.
- The first version focuses on local music playback while the app is open. Background playback with a media notification, lock-screen controls, album-art extraction, playlists saved between sessions, and Android Auto are not included yet.
- The app does not download songs from streaming services. It only plays audio files you already have permission to store on your phone.

## Build the APK online with GitHub Actions (no Android Studio required)

1. On GitHub, create a new repository named `OfflineBeats` (a private repository is fine).
2. Upload the **contents** of this project folder to the repository's main branch. Keep the `.github/workflows/build-apk.yml` file and its folders; on a computer, the easiest method is to upload the extracted project contents. On a phone, GitHub's website may be easier to use in your browser with **Desktop site** enabled.
3. Open the repository's **Actions** tab and select **Build OfflineBeats APK**.
4. If prompted, enable workflows, then choose **Run workflow**. A push to `main` also starts a build automatically.
5. Wait for the workflow to finish with a green check mark. Open that completed run, scroll to **Artifacts**, and download `OfflineBeats-debug-apk`.
6. Extract the downloaded artifact ZIP. It contains `app-debug.apk`. Open the APK on your Android phone to install it; Android may ask you to allow your browser or file manager to install apps.

The GitHub workflow builds a **debug APK** for testing. It is not a Play Store release-signed package. Do not share private passwords or access tokens in the repository.
