package com.offlinebeats.player

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import java.util.Locale

class MainActivity : Activity() {
    private val green = Color.rgb(30, 215, 96)
    private val bg = Color.rgb(18, 18, 18)
    private val panel = Color.rgb(36, 36, 36)
    private val white = Color.WHITE
    private val muted = Color.rgb(179, 179, 179)
    private val songs = mutableListOf<Song>()
    private var visibleSongs = listOf<Song>()
    private var player: MediaPlayer? = null
    private var currentIndex = -1
    private var isShuffle = false
    private var repeatOne = false
    private lateinit var list: LinearLayout
    private lateinit var nowTitle: TextView
    private lateinit var nowArtist: TextView
    private lateinit var playButton: Button
    private lateinit var seek: SeekBar
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestAudioPermission()
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(10))
            setBackgroundColor(bg)
        }
        val brand = TextView(this).apply {
            text = "♫  OfflineBeats"
            textSize = 25f
            setTextColor(green)
            typeface = Typeface.DEFAULT_BOLD
        }
        outer.addView(brand)
        outer.addView(TextView(this).apply {
            text = "YOUR MUSIC. ANYWHERE."
            textSize = 10f; letterSpacing = .18f; setTextColor(muted)
            setPadding(0, dp(4), 0, dp(16))
        })
        status = TextView(this).apply {
            text = "Your downloaded music lives here"
            textSize = 14f; setTextColor(muted)
            setPadding(0, 0, 0, dp(10))
        }
        outer.addView(status)
        val search = EditText(this).apply {
            hint = "Search songs or artists"
            setHintTextColor(muted); setTextColor(white); textSize = 15f
            singleLine = true
            background = rounded(panel, 24)
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        outer.addView(search, LinearLayout.LayoutParams(-1, dp(48)))
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderSongs(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: Editable?) {}
        })
        val heading = TextView(this).apply {
            text = "Your library"
            textSize = 21f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white)
            setPadding(0, dp(18), 0, dp(8))
        }
        outer.addView(heading)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val playerCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(10))
            background = rounded(Color.rgb(42, 42, 42), 18)
        }
        nowTitle = TextView(this).apply {
            text = "Nothing playing"
            textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white)
        }
        nowArtist = TextView(this).apply {
            text = "Choose a song from your library"
            textSize = 12f; setTextColor(muted)
        }
        playerCard.addView(nowTitle)
        playerCard.addView(nowArtist)
        seek = SeekBar(this).apply { progressTintList = android.content.res.ColorStateList.valueOf(green); thumbTintList = android.content.res.ColorStateList.valueOf(green) }
        playerCard.addView(seek)
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        val shuffle = smallButton("Shuffle") { isShuffle = !isShuffle; it.text = if (isShuffle) "Shuffle ✓" else "Shuffle" }
        val prev = smallButton("|◀") { playAt((currentIndex - 1).coerceAtLeast(0)) }
        playButton = smallButton("▶") { togglePlayback() }
        val next = smallButton("▶|") { nextSong() }
        val repeat = smallButton("Repeat") { repeatOne = !repeatOne; it.text = if (repeatOne) "Repeat 1 ✓" else "Repeat" }
        controls.addView(shuffle); controls.addView(prev); controls.addView(playButton); controls.addView(next); controls.addView(repeat)
        playerCard.addView(controls)
        outer.addView(playerCard, LinearLayout.LayoutParams(-1, -2))
        setContentView(outer)
    }

    private fun smallButton(label: String, action: (Button) -> Unit): Button =
        Button(this).apply {
            text = label; textSize = 10f; isAllCaps = false
            setTextColor(if (label == "▶") green else white)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { action(this) }
        }

    private fun requestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(permission), 42)
        } else loadSongs()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) loadSongs()
        else status.text = "Allow audio access to show music saved on this phone."
    }

    private fun loadSongs() {
        songs.clear()
        val collection = if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL) else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        try {
            contentResolver.query(collection, projection, selection, null, sort)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val uri = ContentUris.withAppendedId(collection, id)
                    songs.add(Song(id, c.getString(titleCol) ?: "Unknown title",
                        c.getString(artistCol) ?: "Unknown artist",
                        c.getString(albumCol) ?: "", c.getLong(durationCol), uri.toString()))
                }
            }
        } catch (_: Exception) { }
        status.text = if (songs.isEmpty()) "No music found. Add audio files to your phone and refresh." else "${songs.size} songs available offline"
        renderSongs("")
    }

    private fun renderSongs(query: String) {
        if (!::list.isInitialized) return
        list.removeAllViews()
        visibleSongs = songs.filter { it.title.contains(query, true) || it.artist.contains(query, true) }
        if (visibleSongs.isEmpty()) {
            list.addView(TextView(this).apply {
                text = if (songs.isEmpty()) "Your music library is empty." else "No matching songs."
                setTextColor(muted); setPadding(0, dp(20), 0, dp(20))
            })
        }
        visibleSongs.forEach { song ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(10), dp(10), dp(10))
                background = rounded(panel, 14)
            }
            val art = TextView(this).apply {
                text = "♫"; textSize = 24f; gravity = Gravity.CENTER
                setTextColor(green); background = rounded(Color.rgb(52, 52, 52), 10)
            }
            row.addView(art, LinearLayout.LayoutParams(dp(48), dp(48)))
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
            labels.addView(TextView(this).apply { text = song.title; textSize = 15f; setTextColor(white); maxLines = 1 })
            labels.addView(TextView(this).apply { text = song.artist; textSize = 12f; setTextColor(muted); maxLines = 1 })
            row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this).apply { text = duration(song.duration); setTextColor(muted); textSize = 11f })
            row.setOnClickListener { playAt(songs.indexOf(song)) }
            val params = LinearLayout.LayoutParams(-1, -2)
            params.bottomMargin = dp(7)
            list.addView(row, params)
        }
    }

    private fun playAt(index: Int) {
        if (index !in songs.indices) return
        currentIndex = index
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, Uri.parse(songs[index].uri))
                setOnCompletionListener { if (repeatOne) playAt(currentIndex) else nextSong() }
                prepare()
                start()
            }
            nowTitle.text = songs[index].title
            nowArtist.text = songs[index].artist
            playButton.text = "Ⅱ"
            seek.max = (songs[index].duration / 1000).toInt().coerceAtLeast(1)
            seek.progress = 0
            status.text = "Playing from your offline library"
            updateSeek()
        } catch (e: Exception) {
            status.text = "Couldn't play this file. Try another audio track."
            player?.release(); player = null
        }
    }

    private fun updateSeek() {
        val p = player ?: return
        if (p.isPlaying) {
            try { seek.progress = p.currentPosition / 1000 } catch (_: Exception) {}
            seek.postDelayed({ if (player === p) updateSeek() }, 700)
        }
    }

    private fun togglePlayback() {
        val p = player
        if (p == null) {
            if (songs.isNotEmpty()) playAt(if (currentIndex >= 0) currentIndex else 0)
        } else if (p.isPlaying) {
            p.pause(); playButton.text = "▶"
        } else {
            p.start(); playButton.text = "Ⅱ"; updateSeek()
        }
    }

    private fun nextSong() {
        if (songs.isEmpty()) return
        val next = if (isShuffle) (songs.indices).random() else (currentIndex + 1) % songs.size
        playAt(next)
    }

    private fun duration(ms: Long): String {
        val sec = ms / 1000
        return String.format(Locale.getDefault(), "%d:%02d", sec / 60, sec % 60)
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
